//
//  main.m
//  Oscilloscope-Test
//
//  Created by bach on 21.03.10.
//  Copyright 2010 Universitäts-Augenklinik. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
